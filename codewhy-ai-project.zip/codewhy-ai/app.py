"""CodeWhy AI web server. Run:  python app.py   then open http://127.0.0.1:8501

Uses only the Python standard library plus the `git` command. No pip install needed.
Set CODEWHY_PUBLIC=1 when hosting publicly: only the sample repository can then be opened.
"""
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import engine
import make_sample_repo

HERE = os.path.dirname(os.path.abspath(__file__))
SAMPLE = make_sample_repo.DEST
PUBLIC = os.environ.get("CODEWHY_PUBLIC") == "1"

def ensure_sample():
    if not os.path.isdir(os.path.join(SAMPLE, ".git")):
        make_sample_repo.build()
    return SAMPLE

def resolve(path):
    """Returns repo info; in public mode only the sample repo is allowed."""
    if PUBLIC and os.path.realpath(os.path.expanduser(path or "")) != os.path.realpath(ensure_sample()):
        raise engine.RepoError("This public demo only opens the built-in sample repository.")
    return engine.open_repo(path)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def handle_api(self, route, q):
        if route == "/api/config":
            return {"allow_local": not PUBLIC, "sample_path": ensure_sample(), "public": PUBLIC}
        info = resolve(q.get("repo", ""))
        root = info["root"]
        if route == "/api/repo":
            return {k: v for k, v in info.items()}
        if route == "/api/file":
            lines = engine.read_lines(root, q.get("path", ""))
            return {"path": q["path"], "lines": lines}
        if route == "/api/history":
            if not info["is_git"]:
                return {"commits": [], "note": "No Git history for this folder."}
            return {"commits": engine.file_history(root, q.get("path", ""))}
        if route == "/api/diff":
            return {"diff": engine.commit_diff(root, q.get("hash", ""), q.get("path", ""))}
        if route == "/api/investigate":
            return engine.investigate(root, q.get("path", ""), q.get("start", 1), q.get("end", 1), q.get("question", ""), info)
        raise engine.RepoError("Unknown request.")

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            with open(os.path.join(HERE, "static", "index.html"), "rb") as fh:
                return self.send(200, fh.read(), "text/html")
        if u.path.startswith("/api/"):
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            try:
                return self.send(200, self.handle_api(u.path, q))
            except engine.RepoError as e:
                return self.send(400, {"error": str(e)})
            except Exception as e:  # keep the server alive whatever happens
                return self.send(500, {"error": "Unexpected error: %s" % e})
        self.send(404, {"error": "Not found"})

if __name__ == "__main__":
    ensure_sample()
    port = int(os.environ.get("PORT", 8501))
    host = "0.0.0.0" if (os.environ.get("PORT") or PUBLIC) else "127.0.0.1"
    print("CodeWhy AI running at http://%s:%d  (Ctrl+C to stop)" % ("127.0.0.1" if host != "0.0.0.0" else "localhost", port))
    try:
        ThreadingHTTPServer((host, port), Handler).serve_forever()
    except KeyboardInterrupt:
        sys.exit(0)
