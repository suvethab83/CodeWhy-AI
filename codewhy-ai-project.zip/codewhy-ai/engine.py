"""CodeWhy AI evidence engine (standard library + the `git` command only).

Pipeline: repo -> code -> git history -> docs/comments -> evidence correlation -> explanation.
Everything shown to the user is read from the repository. Nothing is invented.
"""
import os
import re
import subprocess

class RepoError(Exception):
    pass

FMT = "%x1e%H%x1f%h%x1f%an%x1f%aI%x1f%s%x1f%b%x1d"
TEXT_EXT = {".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".go", ".rs", ".rb", ".php", ".cs", ".html", ".css",
            ".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".txt", ".md", ".rst", ".sh", ".sql", ".xml", ".env"}
SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "__pycache__", "dist", "build"}
STRONG_RE = re.compile(r"\b(because|due to|so that|so (we|it|every|each|the)|in order to|to (avoid|prevent|stop)|work ?around|"
                       r"otherwise|caused|root cause|instead of|(fixes|closes) #\d+|broke|made it worse|could (double|break|fail))\b")
def has_reason(text):
    return bool(STRONG_RE.search(text.lower()))

STRONG = ("because", "due to", "so that", "in order to", "to avoid", "to prevent", "workaround", "work around",
          "otherwise", "caused", "root cause", "instead of", "fixes #", "closes #", "so we", "broke", "made it worse")
WEAK = ("fix", "bug", "issue", "error", "429", "limit", "regression", "compat", "security", "deprecat", "mismatch",
        "crash", "fail", "slow", "retry", "retries")
GENERIC = {"update", "updates", "misc", "misc updates", "wip", "changes", "fix", "fixes", "tweak", "cleanup", "stuff"}
STOP = set("""self return print none true false import from else elif range with this that have then than into
for while def class pass break continue lambda not and the are was were will would should could which what when
where there their they them value values data item items name text file line lines code""".split())

HYPOTHESES = [  # (pattern, hypothesis, words that would support it)
    (r"sleep|retry|retries|backoff|attempt", "Delay/retry logic is often added to cope with temporary failures such as "
     "rate limits or network errors.", ("rate", "429", "retry", "back off", "temporar")),
    (r"Decimal|quantize|round\(", "Exact decimal arithmetic or rounding is often used to avoid floating-point errors "
     "in money values.", ("float", "decimal", "cent", "round", "invoice")),
    (r"^\s*[A-Za-z0-9_.-]+\s*(==|<=|<|~=)\s*\d", "A pinned or capped dependency version usually avoids a breaking "
     "change or incompatibility.", ("pin", "compat", "broke", "version", "ssl")),
    (r"except\s*(Exception)?\s*:", "A broad except often keeps a program running when unexpected errors occur.", ("error",)),
    (r"\b[A-Z][A-Z_]{3,}\s*=\s*\d+|[*+]\s*\d{2,}", "A hard-coded constant can encode a business rule, a unit conversion "
     "or a tuned value. Only the repository (or its author) can say which.", ()),
    (r"TODO|FIXME|HACK|XXX", "A TODO/FIXME/HACK marker flags code the author knew was temporary or unfinished.", ()),
    (r"timeout\s*=", "An explicit timeout prevents a call from hanging forever.", ("timeout", "hang")),
]

def git(root, *args):
    try:
        r = subprocess.run(["git", "-c", "safe.directory=*", "-C", root, *args], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=30)
    except (OSError, subprocess.SubprocessError) as e:
        raise RepoError("Git could not be run: %s. Is Git installed and on your PATH?" % e)
    return r.stdout if r.returncode == 0 else ""

def open_repo(path):
    path = os.path.abspath(os.path.expanduser((path or "").strip()))
    if not os.path.isdir(path):
        raise RepoError("Folder not found: %s" % path)
    top = git(path, "rev-parse", "--show-toplevel").strip()
    is_git = bool(top)
    root = os.path.normpath(top) if is_git else path
    commits = git(root, "rev-list", "--count", "HEAD").strip() if is_git else "0"
    branch = git(root, "rev-parse", "--abbrev-ref", "HEAD").strip() if is_git else ""
    files = list_files(root, is_git)
    docs = [f for f in files if is_doc(f["path"])]
    warnings = []
    if not is_git:
        warnings.append("This folder is not a Git repository, so history evidence is unavailable. "
                        "Only code comments and documentation can be searched.")
    elif commits in ("", "0"):
        warnings.append("This repository has no commits yet, so there is no history to investigate.")
    if not docs:
        warnings.append("No README or documentation files were found.")
    return {"root": root, "name": os.path.basename(root), "is_git": is_git, "branch": branch,
            "commits": int(commits or 0), "files": files, "docs": len(docs), "warnings": warnings}

def is_doc(p):
    return p.lower().endswith((".md", ".rst", ".txt")) and "requirements" not in p.lower() or p.lower().startswith("docs/")

def list_files(root, is_git):
    names = [n for n in git(root, "ls-files", "-z").split("\0") if n] if is_git else []
    if not names:  # not a repo, or nothing committed yet: fall back to walking the folder
        names = []
        for d, dirs, fs in os.walk(root):
            dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
            names += [os.path.relpath(os.path.join(d, f), root).replace(os.sep, "/") for f in fs]
    out = []
    for n in sorted(names)[:400]:
        ext = os.path.splitext(n)[1].lower()
        try:
            size = os.path.getsize(os.path.join(root, n))
        except OSError:
            continue
        readable = ext in TEXT_EXT and size < 400_000
        out.append({"path": n, "readable": readable, "size": size})
    return out

def read_lines(root, rel):
    full = os.path.realpath(os.path.join(root, rel))
    if not full.startswith(os.path.realpath(root) + os.sep) or not os.path.isfile(full):
        raise RepoError("File not found in this repository: %s" % rel)
    with open(full, "rb") as fh:
        data = fh.read(400_001)
    if b"\0" in data[:4096] or len(data) > 400_000:
        raise RepoError("Unsupported file (binary or too large): %s" % rel)
    return data.decode("utf-8", "replace").splitlines()

def parse_commits(out):
    res = []
    for rec in out.split("\x1e")[1:]:
        head, _, rest = rec.partition("\x1d")
        f = head.split("\x1f")
        if len(f) < 6:
            continue
        res.append({"hash": f[0], "short": f[1], "author": f[2], "date": f[3], "subject": f[4],
                    "body": f[5].strip(), "rest": rest.strip("\n")})
    return res

def file_history(root, rel):
    out = git(root, "log", "--follow", "--numstat", "--format=" + FMT, "--", rel)
    res = parse_commits(out)
    for c in res:
        add = dele = 0
        for ln in c.pop("rest").splitlines():
            m = re.match(r"^(\d+)\t(\d+)\t", ln)
            if m:
                add += int(m.group(1)); dele += int(m.group(2))
        c["added"], c["deleted"] = add, dele
        c["quality"] = classify(c["subject"], c["body"])
    return res

def commit_diff(root, h, rel):
    if not re.fullmatch(r"[0-9a-f]{7,40}", h or ""):
        raise RepoError("Invalid commit id.")
    out = git(root, "show", "--format=", "--patch", h, "--", rel) or git(root, "show", "--format=", "--patch", h)
    return "\n".join(out.splitlines()[:160])

def classify(subject, body):
    t = (subject + "\n" + body).lower()
    if has_reason(t):
        return "reasoned"
    if subject.lower().strip(" .") in GENERIC or len(subject.split()) <= 2:
        return "generic"
    return "hint" if any(c in t for c in WEAK) else "plain"

def reason_sentence(text):
    text = re.sub(r"\n(?!\s*([-*#]|\d+\.))", " ", text)  # re-join hard-wrapped lines
    parts = [p.strip() for p in re.split(r"(?<=[.!?])\s+|\n+", text) if p.strip()]
    for p in parts:
        if has_reason(p):
            return p[:240]
    for p in parts:
        if any(c in p.lower() for c in WEAK):
            return p[:240]
    return parts[0][:240] if parts else ""

def blame(root, rel, s, e):
    out = git(root, "blame", "-L", "%d,%d" % (s, e), "--line-porcelain", "--", rel)
    res, cur = {}, None
    for ln in out.splitlines():
        m = re.match(r"^([0-9a-f]{40}) \d+ (\d+)", ln)
        if m:
            cur = {"hash": m.group(1), "line": int(m.group(2))}
        elif cur and ln.startswith("summary "):
            cur["summary"] = ln[8:]
        elif cur and ln.startswith("\t"):
            res[cur["line"]] = cur; cur = None
    return res

def stem_set(text):
    return {w[:4] for w in re.findall(r"[a-z]{4,}", re.sub(r"([a-z])([A-Z])", r"\1 \2", text).lower()) if w not in STOP}

def distinctive_tokens(snippet):
    toks = re.findall(r"\b[A-Z][A-Z0-9_]{3,}\b", snippet)
    toks += re.findall(r"^\s*(?:import|from)\s+([A-Za-z_]\w*)", snippet, re.M)
    toks += re.findall(r"^\s*([A-Za-z0-9_.-]+)\s*[=<>~!]=?\s*\d", snippet, re.M)
    toks += re.findall(r"def\s+(\w+)|class\s+(\w+)", snippet) and [a or b for a, b in re.findall(r"def\s+(\w+)|class\s+(\w+)", snippet)]
    toks += [s for s in re.findall(r"[\"']([\w./-]{4,30})[\"']", snippet)]
    seen, out = set(), []
    for t in toks:
        if t not in seen and t.lower() not in STOP:
            seen.add(t); out.append(t)
    return out[:4]

def doc_paragraphs(root, files):
    for f in files:
        if not (f["readable"] and is_doc(f["path"])):
            continue
        try:
            lines = read_lines(root, f["path"])
        except RepoError:
            continue
        start, buf = 1, []
        for i, ln in enumerate(lines + [""], 1):
            if ln.strip():
                if not buf:
                    start = i
                buf.append(ln)
            elif buf:
                yield f["path"], start, i - 1, "\n".join(buf)
                buf = []

def investigate(root, rel, s, e, question, repo_info):
    lines = read_lines(root, rel)
    if not lines:
        raise RepoError("This file is empty.")
    s = max(1, min(int(s), len(lines))); e = max(s, min(int(e), len(lines)))
    snippet = "\n".join(lines[s - 1:e])
    q = (question or "").lower()
    qtype = ("dependency" if "dependenc" in q else "workaround" if "workaround" in q else "changed" if "chang" in q
             else "problem" if ("problem" in q or "solve" in q) else "condition" if "condition" in q else "general")
    ev, is_git = {}, repo_info["is_git"]

    def add(c, kind):
        d = ev.setdefault(c["hash"], {"hash": c["hash"], "short": c["short"], "subject": c["subject"],
                                      "body": c["body"], "date": c["date"], "author": c["author"], "kinds": [],
                                      "quality": classify(c["subject"], c["body"])})
        if kind not in d["kinds"]:
            d["kinds"].append(kind)

    if is_git:
        for ln, b in blame(root, rel, s, e).items():
            h = git(root, "log", "-1", "--format=" + FMT, b["hash"])
            for c in parse_commits(h):
                add(c, "introduced the current version of line %d" % ln if s == e else "introduced current lines")
        for c in parse_commits(git(root, "log", "-L", "%d,%d:%s" % (s, e, rel), "--format=" + FMT)):
            add(c, "changed the selected lines")
        for t in distinctive_tokens(snippet):
            for c in parse_commits(git(root, "log", "-S", t, "-n", "4", "--format=" + FMT, "--", ".", ":(exclude)*.md", ":(exclude)*.rst")):
                add(c, "added or removed `%s`" % t)
    commits = list(ev.values())
    for c in commits:
        c["quote"] = reason_sentence(c["body"] or c["subject"]) if c["quality"] in ("reasoned", "hint") else ""
        if c["quality"] == "reasoned":
            c["quote"] = reason_sentence(c["subject"] + "\n" + c["body"])
    rank = {"reasoned": 0, "hint": 1, "plain": 2, "generic": 3}
    commits.sort(key=lambda c: (c["date"],), reverse=True)
    if qtype != "changed":
        commits.sort(key=lambda c: (rank[c["quality"]], 0 if qtype == "dependency" and any("added or" in k for k in c["kinds"]) else 1))
    commits = commits[:6]

    # comments near the selection
    comments = []
    for i in range(max(1, s - 3), min(len(lines), e + 3) + 1):
        m = re.search(r"(#|//)\s*(.+)$", lines[i - 1])
        if m and not lines[i - 1].strip().startswith("#!"):
            txt = m.group(2).strip()
            comments.append({"file": rel, "line": i, "text": txt, "reasoned": has_reason(txt)})

    # documentation search
    keys = stem_set(snippet) | stem_set(question or "")
    for c in commits:
        if c["quality"] in ("reasoned", "hint") and any(not k.startswith("added or") for k in c["kinds"]):
            keys |= stem_set(c["subject"] + " " + c["body"])
    refs = {m.lower() for c in commits for m in re.findall(r"[\w./-]+\.(?:md|rst|txt)", c["body"] + c["subject"])}
    docs = []
    for path, a, b, text in doc_paragraphs(root, repo_info["files"]):
        if path == rel:
            continue
        hit = keys & stem_set(text)
        score = len(hit) + (3 if path.lower() in refs else 0)
        if len(hit) >= 2 and not text.lstrip().startswith("#"):
            docs.append({"file": path, "start": a, "end": b, "text": text[:420], "score": score, "hits": len(hit),
                         "reasoned": has_reason(text), "linked": path.lower() in refs})
    docs.sort(key=lambda d: -d["score"])
    if docs:
        docs = [d for d in docs if d["hits"] >= max(2, docs[0]["hits"] - 1)][:3]

    # correlate and rate
    sources = []
    if any(c["quality"] == "reasoned" for c in commits): sources.append("Git commit message")
    if any(d["reasoned"] for d in docs): sources.append("documentation")
    if any(c["reasoned"] for c in comments): sources.append("code comment")
    if len(sources) >= 2: level = "strong"
    elif sources: level = "moderate"
    elif any(c["quality"] == "hint" for c in commits) or docs: level = "weak"
    else: level = "insufficient"
    labels = {"strong": "Strong evidence", "moderate": "Documented in one source", "weak": "Weak evidence, mostly inference",
              "insufficient": "Insufficient evidence"}
    reasons = []
    if not is_git:
        reasons.append("No Git history is available for this folder.")
    else:
        reasons.append("%d commit(s) were linked to the selected lines (via git blame, git log -L, and term search)." % len(commits))
    for c in commits:
        if c["quality"] == "reasoned":
            reasons.append("Commit %s explains a reason in its own message." % c["short"])
    if commits and commits[0]["quality"] == "generic" and not sources:
        reasons.append("The commits found have generic messages (e.g. \"%s\") that say nothing about intent." % commits[0]["subject"])
    reasons.append("%d documentation paragraph(s) matched the code and question." % len(docs) if docs else
                   "No documentation paragraph matched the selected code.")
    if comments:
        reasons.append("%d code comment(s) sit next to the selection%s." % (len(comments), "" if any(c["reasoned"] for c in comments) else ", but none states a reason"))
    documented = []
    for c in commits:
        if c["quality"] == "reasoned":
            documented.append({"source": "commit %s" % c["short"], "text": c["quote"], "date": c["date"][:10]})
    for d in docs:
        if d["reasoned"]:
            documented.append({"source": "%s:%d-%d" % (d["file"], d["start"], d["end"]), "text": reason_sentence(d["text"]), "date": ""})
    for c in comments:
        if c["reasoned"]:
            documented.append({"source": "%s:%d" % (c["file"], c["line"]), "text": c["text"], "date": ""})
    summaries = {
        "strong": "The repository itself records why this code exists, in more than one place (%s). The quoted statements below are copied from those sources." % " and ".join(sources),
        "moderate": "One source (%s) states a reason. Nothing else in the repository confirms it, so treat it as documented but uncorroborated." % sources[0] if sources else "",
        "weak": "The repository hints at the area this code deals with, but no source states why it was written this way. Everything below the evidence is inference.",
        "insufficient": "The repository does not contain enough evidence to establish why this code exists. We will not guess: ask the author, or check issues and pull requests that are not stored in Git.",
    }
    hyps = []
    for pat, text, support in HYPOTHESES:
        if re.search(pat, snippet, re.M | re.I if pat.startswith("sleep") else re.M):
            quoted = " ".join(d["text"] for d in documented).lower()
            hyps.append({"text": text, "supported": bool(support) and any(w in quoted for w in support)})
    related = find_related(root, rel, snippet, repo_info, commits)
    return {"selection": {"file": rel, "start": s, "end": e, "snippet": snippet}, "qtype": qtype,
            "status": {"level": level, "label": labels[level], "reasons": reasons},
            "summary": summaries[level], "documented": documented, "hypotheses": hyps[:3],
            "commits": commits, "docs": docs, "comments": comments, "related": related,
            "mode": "Rule-based evidence engine (no LLM)"}

def find_related(root, rel, snippet, repo_info, commits):
    names = re.findall(r"def\s+(\w+)|class\s+(\w+)|^\s*([A-Z][A-Z0-9_]{3,})\s*=", snippet, re.M)
    names = [a or b or c for a, b, c in names][:4]
    out = []
    for f in repo_info["files"]:
        if f["path"] == rel or not f["readable"]:
            continue
        try:
            lines = read_lines(root, f["path"])
        except RepoError:
            continue
        for n in names:
            for i, ln in enumerate(lines, 1):
                if re.search(r"\b%s\b" % re.escape(n), ln):
                    out.append({"file": f["path"], "line": i, "why": "mentions `%s`" % n}); break
    if repo_info["is_git"]:
        for c in commits[:3]:
            names = git(root, "show", "--name-only", "--format=", c["hash"]).split()
            for fn in (names if len(names) <= 4 else []):
                if fn != rel and not any(o["file"] == fn for o in out):
                    out.append({"file": fn, "line": 1, "why": "changed in the same commit as this code (%s)" % c["short"]})
    return out[:6]
