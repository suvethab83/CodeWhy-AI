# CodeWhy AI

**Don't Just Read the Code. Discover Why It Exists.**

CodeWhy AI is an AI-assisted code archaeology tool for the *HackFront India AI + Software Builder Challenge*.
Select lines of code, ask "why?", and it searches the repository's own Git history, documentation and comments.
Every answer is labelled **Documented**, **Inferred** or **Unknown**, with commit IDs and file:line references.

> **Problem statement:** Develop an AI-powered system that reconstructs the hidden reasoning behind existing code by
> connecting code changes, Git history, and documentation to deliver evidence-backed explanations of why the code
> exists, not just what it does.

**Honest scope.** This prototype uses a *rule-based evidence engine*. It does **not** call any LLM, so it needs no API
key. It never invents commits, quotes or line numbers, and it says "Insufficient evidence" when the repository cannot
answer. Optional LLM explanations are future work (see the feature table).

**Why not Streamlit?** The brief preferred Streamlit + GitPython. The environment this was built in had no internet, so
those packages could not be installed or tested. I chose a standard-library web server and the `git` command instead,
so everything here was actually run and verified, and you need no `pip install` at all.

---

## 1. Quick start on Windows + VS Code (beginner friendly)

1. **Install Python 3.9 or newer** from <https://www.python.org/downloads/>. On the first installer screen, tick
   **"Add python.exe to PATH"**.
2. **Install Git** from <https://git-scm.com/download/win> (accept the defaults).
3. **Install VS Code** from <https://code.visualstudio.com/> and, inside it, the **Python** extension (optional but nice).
4. Unzip the project, then in VS Code choose **File > Open Folder** and pick the `codewhy-ai` folder.
5. Open a terminal: **Terminal > New Terminal**. Check the tools:
   ```
   python --version
   git --version
   ```
   (If `python` is not found, try `py --version` and use `py` instead of `python` below.)
6. Start the app:
   ```
   python app.py
   ```
   The first run creates the **sample repository** automatically (a small Git repo in `sample_repo/`).
7. Open **http://127.0.0.1:8501** in your browser. Press `Ctrl+C` in the terminal to stop.

macOS / Linux: the same steps work with `python3 app.py`.

**Use your own project:** paste the folder path (for example `C:\Users\you\my-project`) into the Repository box and
press **Load**. The folder should be a Git repository for history evidence; plain folders still work for docs and
comments, with a warning.

## 2. How to use it

1. Click **Use sample repository** (or **Run the sample investigation** for the one-click version).
2. Click a file in the explorer.
3. Click a line in the code viewer (Shift+click to select a range).
4. Type a question or click an example chip, then press **Investigate**.
5. Read the right-hand panel: evidence status, quoted facts, labelled hypotheses, commits, documentation, comments,
   *how we reached this conclusion*, and related code. Click a commit title in the timeline (or **Show diff**) to see
   the real diff.

### The four evidence levels

| Level | Meaning |
|---|---|
| Strong evidence | At least two independent sources (commit message, documentation, code comment) state a reason |
| Documented in one source | One source states a reason; nothing corroborates it |
| Weak evidence, mostly inference | Related commits or docs exist, but none states a reason |
| Insufficient evidence | Nothing in the repository establishes why the code exists |

A "reason" means the text contains explicit reasoning language ("because", "to avoid", "so that", "workaround",
"fixes #12", and similar English phrases). Quoted text is copied verbatim from the repository.

## 3. The sample repository (SAMPLE DATA)

`make_sample_repo.py` generates **ShopLedger**, a tiny *synthetic* project with 7 commits and 2 docs. It is **not** a real
third-party project; its commits are generated and clearly labelled in the UI ("SAMPLE DATA"). Dates and authors are
fixed, so commit IDs are identical on every machine. Four scenarios cover every evidence level:

| Try this | Expected result |
|---|---|
| `payments.py` line 24 (`time.sleep(...)`) | **Strong**: commit `083ceec` and `docs/gateway-notes.md` both state a reason |
| `pricing.py` lines 8-10 | **Documented in one source**: commit `ffd3abe` (Decimal instead of float) |
| `requirements.txt` line 1 | **Documented in one source**: commit `4b5e4b1` (why `requests` is pinned) |
| `utils.py` lines 2-6 | **Insufficient evidence**: the only commit is called "misc updates" |

Rebuild it any time with `python make_sample_repo.py`.

## 4. Demo script (about 2 minutes)

| Click | Say |
|---|---|
| Landing page | "When you inherit code you can see *what* it does, but not *why* it exists. CodeWhy AI answers every question with one of three labels: documented, inferred, or unknown." |
| **Use sample repository**, open `payments.py` | "This is a sample project, clearly labelled as synthetic data." |
| Click line 24, press **Investigate** (question: *Why does this workaround exist?*) | "I ask why this `sleep` exists." |
| Point at the status card | "Strong evidence: two independent sources state the reason." |
| Point at the green **Documented** quotes | "These quotes are copied word for word from commit `083ceec` and `docs/gateway-notes.md`. Nothing is paraphrased or invented." |
| Point at the amber **Inferred** card | "This is the AI-style hypothesis. It is labelled as inference and marked consistent with the evidence." |
| Click **Show diff** or the commit in the timeline | "Everything is traceable to a real commit." |
| Open `utils.py`, select lines 2-6, ask again | "Now the honest case. The only commit is 'misc updates', so the answer is **Insufficient evidence**. We refuse to guess." |
| Close | "Don't just read the code. Discover why it exists." |

## 5. Implemented vs future features

| Feature | Status |
|---|---|
| Repository selection (local path) and built-in sample repository | Implemented |
| Code explorer with line numbers, syntax colouring, line/range selection | Implemented |
| Git history timeline from real commits, with diffs | Implemented |
| Line-level evidence via `git blame`, `git log -L`, `git log -S` | Implemented |
| Documentation, README and nearby-comment search | Implemented |
| Five example "Why?" questions and free-text questions | Implemented |
| Evidence status meter, verbatim quotes, labelled hypotheses, "why this conclusion" list | Implemented |
| Related files (shared names, changed in same commit) | Implemented |
| Error handling: bad path, no Git history, no docs, binary/unsupported files, path traversal | Implemented |
| Public-demo mode (`CODEWHY_PUBLIC=1`: sample repo only) | Implemented |
| Responsive layout (laptop and phone widths) | Implemented |
| Optional LLM explanations grounded in the retrieved evidence | **Future work** |
| Import GitHub issues and pull requests | **Future work** |
| Function-level parsing for many languages | **Future work** |
| Evaluation on real open-source repositories | **Future work** |
| IDE extension | **Future work** |

Known limits: reason detection uses English phrases; explanations are only as good as the repository's commit messages and
docs; multi-line string highlighting is basic; `git log -L` works best on languages Git can follow by line range.

## 6. Project layout

```
app.py                web server + API routes (standard library)
engine.py             evidence engine: Git analysis, doc search, rating, explanation
make_sample_repo.py   builds the synthetic sample repository
static/index.html     the whole user interface (HTML, CSS, JavaScript)
screenshots/          real screenshots of the running app (used in the deck)
requirements.txt      intentionally empty of packages
Dockerfile            for container hosting (see below)
```

## 7. Deploying to a public HTTPS URL

I could not deploy from the authoring environment, so **no public URL exists yet and none is claimed**. These steps are
untested here. Do not host with local-folder access: `CODEWHY_PUBLIC=1` limits the site to the sample repository so
visitors cannot read the server's files.

**Option A: Render.com (free tier, simplest)**
1. Put the project on GitHub (add `sample_repo/` to `.gitignore`; it is already listed).
2. In Render choose **New > Web Service**, connect the repository.
3. Runtime **Python**, Build Command `echo ok`, Start Command `python app.py`.
4. Add environment variable `CODEWHY_PUBLIC` = `1`. Render supplies `PORT` automatically.
5. Deploy. Render gives you an `https://<name>.onrender.com` URL. Open it and run the sample investigation to verify.
   If Git is missing in the build image, choose **Docker** instead and use the included `Dockerfile`.

**Option B: Hugging Face Spaces (Docker)**
1. Create a new Space, SDK **Docker**. Upload the project files (including the `Dockerfile`).
2. Add `app_port: 7860` to the Space's README header if asked. The Dockerfile already sets `PORT=7860` and `CODEWHY_PUBLIC=1`.
3. After the build finishes, the Space URL is your public HTTPS link.

**Secrets:** this prototype uses none. If you later add an LLM, store its key in the platform's *environment variables / secrets*,
never in the code or in Git.

## 8. Troubleshooting

| Problem | Fix |
|---|---|
| `python` is not recognised | Reinstall Python and tick "Add python.exe to PATH", or use `py app.py` |
| "Git could not be run" | Install Git and restart VS Code so the PATH refreshes |
| Port 8501 already in use | `set PORT=8600` then `python app.py`, and open `http://127.0.0.1:8600` |
| "not a Git repository" warning | Run `git init` and commit, or pick a folder that has a `.git` folder |
| Sample repo looks wrong | Delete the `sample_repo` folder and run `python make_sample_repo.py` |
